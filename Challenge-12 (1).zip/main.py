def Leapyear(year):
  if year % 4 == 0 and year % 10 == 0 or year % 400 == 0:
     return True
  else:
     return False 


year = int(input(" Ente a year:")) 

if Leapyear(year):
    print('{} is a leap year.'.format(year))
else:
   print('{}is not a leap )year.'.format(year))
